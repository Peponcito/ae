import { useEffect, useState } from 'react';
import ContainerPost from './components/ContainerPost';
import Navbar from './components/Navbar';

const defaultPost = [];

const App = () => {
  const doGetCategories = () => {
    const result = JSON.parse(localStorage.getItem('post'));
    return result || defaultPost;
  };

  const [datosUser, setDatosUser] = useState({
    usuario: '',
    password: ''
  });

  const [post, setPost] = useState(doGetCategories());
  useEffect(() => {
    localStorage.setItem('post', JSON.stringify(post));
  }, [post]);

  const handleDelete = (id) => {
    setPost(post.filter((post) => post.id !== id));
  };

  return (
    <div>
      <Navbar datosUser={datosUser} setDatosUser={setDatosUser} />
      {datosUser.password && <ContainerPost datosUser={datosUser} post={post} setPost={setPost} handleDelete={handleDelete} />}
    </div>
  );
};

export default App;
