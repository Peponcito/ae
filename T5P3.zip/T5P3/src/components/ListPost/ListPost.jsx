import PropTypes from 'prop-types';
import Post from '../Post';

const ListPost = ({ post, handleDelete }) => {
  return (
    <div className='row mt-4 overflow'>
      {post.map((post) => {
        return <Post key={post.id} id={post.id} autor={post.autor} titulo={post.titulo} mensaje={post.mensaje} handleDelete={handleDelete} />;
      })}
    </div>
  );
};
ListPost.propTypes = {
  post: PropTypes.array,
}
ListPost.propTypes = {
  handleDelete: PropTypes.func
};
export default ListPost;
