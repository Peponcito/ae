import PropTypes from 'prop-types';
const Logout = ({ datosUser, setDatosUser }) => {
  const Logout = () =>{
    setDatosUser({
        usuario: '',
        password: ''
    });
}
  return (
    <div> 
        <h6> Usuario: <span className="user">{datosUser.usuario}</span>
        <button className="btn boton" onClick={Logout}>Logout</button>
        </h6>
    </div>
  );
};

Logout.propTypes = {
  datosUser: PropTypes.object,
}
Logout.propTypes = {
  setDatosUser: PropTypes.func
};

export default Logout;
