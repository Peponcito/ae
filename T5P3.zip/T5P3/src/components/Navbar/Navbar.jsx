import Login from '../Login';
import Logout from '../Logout';

import PropTypes from 'prop-types';

const Navbar = ({ datosUser, setDatosUser }) => {
  return (
    <nav className="navbar navbar-expand-lg bg-dark">
  <div className="container-fluid">
    <img className="navbar-brand" src='./logo.png' alt="#" />
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          <a className="nav-link">Inicio</a>
        </li>
        <li className="nav-item">
          <a className="nav-link">Acerca de</a>
        </li>
        <li className="nav-item">
          <a className="nav-link">Contacto</a>
        </li>
      </ul>
      {
        datosUser.usuario 
          ? <Logout datosUser={datosUser} setDatosUser={setDatosUser}/>
          : <Login datosUser={datosUser} setDatosUser={setDatosUser} />
      }
    </div>
  </div>
</nav>
  );
};

Navbar.propTypes = {
  datosUser: PropTypes.object,
}
Navbar.propTypes = {
  setDatosUser: PropTypes.func,
}
Navbar.propTypes = {
  setPostData: PropTypes.func
};

export default Navbar;
