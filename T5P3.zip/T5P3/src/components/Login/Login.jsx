import PropTypes from 'prop-types';
import { useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Login = ({ setDatosUser }) => {
  const showToast = () => {
    toast.error('Usuario o contraseña incorrectos', {
      position: "top-left",
      autoClose: 1000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      });
  };

  const initUser = {
    usuario: '',
    password: ''
  };

  const [form, setFormState] = useState(initUser);

  const handleInputChange = (e) => {
    setFormState({
      ...form,
      [e.target.name]: e.target.type === 'checkbox' ? e.target.checked : e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (form.password !== '123' || form.usuario === '') {
      // window.alert('Contraseña incorrecta')
      showToast()
      return
      }
      setDatosUser(form);
  };
  return (
    <form className="d-flex" role="text" onSubmit={handleSubmit}>
        <input 
        className="form-control me-2" 
        type="text"
        id="usuario"
        name="usuario" 
        placeholder="Usuario"
        onChange={handleInputChange}
        />

        <input 
        className="form-control me-2" 
        type="password"
        id="password"
        name="password" 
        placeholder="Password"
        onChange={handleInputChange}
        />
        <button className="btn boton" type="submit">Login</button>
        <ToastContainer/>
    </form>
  );
};

Login.propTypes = {
  setDatosUser: PropTypes.func
};

export default Login;
