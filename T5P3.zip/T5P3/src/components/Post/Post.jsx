import PropTypes from 'prop-types';

const Post = ({ id, autor, titulo, mensaje, handleDelete }) => {
  return (
    <div className='barra'>
      <div className='col'>
        <p className='form-label linea'>
          <strong>{titulo}</strong>
        </p>
      </div>

      <div className='col'>
        <span className='form-label'>{mensaje}</span>
      </div>

      <div className='col written'>
        <p className='form-label'>
          <i>
            Written by <strong>{autor}</strong>
          </i>
          <button className='btn basura' type='button' onClick={() => handleDelete(id)}>
            <i className='bi bi-trash'></i>
          </button>
        </p>

        <div className='col'></div>
      </div>
    </div>
  );
};

Post.propTypes = {
  id: PropTypes.string,
}
Post.propTypes = {
  autor: PropTypes.string,
}
Post.propTypes = {
  titulo: PropTypes.string,
}
Post.propTypes = {
  mensaje: PropTypes.string,
}
Post.propTypes = {
  handleDelete: PropTypes.func
};

export default Post;
