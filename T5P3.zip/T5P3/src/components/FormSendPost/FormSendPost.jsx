import PropTypes from 'prop-types';
import { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';

const FormSendPost = ({ datosUser, setPost, post }) => {
  const initUser = {
    autor: datosUser.usuario,
    titulo: '',
    mensaje: ''
  };

  const [form, setFormState] = useState(initUser);

  const handleInputChange = (e) => {
    // console.log(e.target.name);
    // console.log(e.target.value);
    setFormState({
      ...form,
      [e.target.name]: e.target.type === 'checkbox' ? e.target.checked : e.target.value
    });
  };

  const handleAdd = () => {
    setPost([{ id: uuidv4(), autor: form.autor, titulo: form.titulo, mensaje: form.mensaje }, ...post]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // if (form.mensaje === 'Error'){
    // console.log('Entro');
    //  setFormState({
    //    ...form,
    //    mensaje: 'solucion'
    //  })
    // }
    handleAdd();
    setFormState(initUser);
  };

  return (
    <div className="contenedor">
      <div>
      <p className="titulo">Autor: <strong>{form.autor}</strong></p>
      </div >
      <div className="contenido">
        <form onSubmit={handleSubmit}>
        <div className="col mb-3">
          <p>
          <label htmlFor="name" className="form-label">Título</label>
          <input 
            type="text" 
            className="form-control" 
            id="titulo"
            name="titulo" 
            onChange={handleInputChange}
            value = {
              form.titulo
            }
            />
            </p>
        </div>
        <div className="col mb-3">
          <p>
          <label htmlFor="surname" className="form-label">Mensaje</label>
          <textarea 
            type="text" 
            className="form-control" 
            id="mensaje"
            name="mensaje" 
            placeholder="Tu texto..."
            onChange={handleInputChange}
            value = {
              form.mensaje
            }
            />
            </p>
        </div>
        <div className="col">
          <div className="row">
            <div className="col-6">
            {
              form.mensaje === '' || form.titulo === ''
              ? <button className="btn botonPost" type="submit" disabled>Nuevo Post</button>
              : <button className="btn botonPost" type="submit">Nuevo Post</button>
            }
            </div>
          </div>
        </div>
      </form>
      </div>
    </div>
  );
};

FormSendPost.propTypes = {
  datosUser: PropTypes.object,
}
FormSendPost.propTypes = {
  setPost: PropTypes.func,
}
FormSendPost.propTypes = {
  post: PropTypes.array
};

export default FormSendPost;
