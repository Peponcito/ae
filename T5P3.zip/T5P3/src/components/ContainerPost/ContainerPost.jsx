import PropTypes from 'prop-types';
import FormSendPost from '../FormSendPost';
import ListPost from '../ListPost';

const ContainerPost = ({ datosUser, post, setPost, handleDelete }) => {
  return (
    <div className="col">
          <div className="row">
            <div className="col-6">
              <FormSendPost datosUser={datosUser} setPost={setPost} post = {post}/>
            </div>
            <div className="col-6">
            <ListPost post={post} handleDelete = {handleDelete}/>
            </div>
          </div>
        </div>
  );
};

ContainerPost.propTypes = {
  datosUser: PropTypes.object,
}
ContainerPost.propTypes = {
  post: PropTypes.array,
}
ContainerPost.propTypes = {
  setPost: PropTypes.func,
}
ContainerPost.propTypes = {
  handleDelete: PropTypes.func
};

export default ContainerPost;
