import { useEffect, useState } from 'react';
import ContainerPost from './components/ContainerPost';
import Navbar from './components/Navbar';

const defaultPosts = [];

const App = () => {
  const doGetPosts = () => {
    const result = JSON.parse(localStorage.getItem('posts'));
    return result || defaultPosts;
  };

  /**
   * LOCALSTORAGE:
   * - setItem: Usado para añadir una key: value al Storage
   * - getItem: Devuelve un item desde el localStorage dado una key
   * - removeItem: Elimina un item dada una key
   * - clear: Elimina todas las instancias del localStorage
   * - key: devuelve la key dado un número
   */

  const [usuario, setUsuario] = useState({
    usuario: '',
    password: ''
  });

  const [posts, setPosts] = useState(doGetPosts());
  useEffect(() => {
    localStorage.setItem('posts', JSON.stringify(posts));
  }, [posts]);

  // [] se ejecutará una unica vez al cargar el componente

  // Nada Se ejecutará en cada renderizado del componente

  // [estado] se ejecutará en cada cambio que sufra el estado

  const handleDelete = (id) => {
    setPosts(posts.filter((post) => post.id !== id));
  };

  return (
    <div>
      <Navbar datosUsuario={usuario} setUsuario={setUsuario} />
      <ContainerPost datosUsuario={usuario} posts={posts} setPosts={setPosts} handleDelete={handleDelete} />
    </div>
  );
};

export default App;
