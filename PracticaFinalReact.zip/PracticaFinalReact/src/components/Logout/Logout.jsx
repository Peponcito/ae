import PropTypes from 'prop-types';
const Logout = ({ datosUsuario, setUsuario }) => {
  return (
    <div className='d-flex' role='search'>
      <p className='nav-objeto'>
        Usuario: <span className='blanco'> {datosUsuario.usuario}</span>
      </p>
      <button
        className='btn btn-warning'
        onClick={() => {
          setUsuario({
            usuario: '',
            password: ''
          });
        }}
      >
        Logout
      </button>
    </div>
  );
};

Logout.propTypes = {
  datosUsuario: PropTypes.object,
  setUsuario: PropTypes.func
};

export default Logout;
