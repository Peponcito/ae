import PropTypes from 'prop-types';
import { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';

const FormSendPost = ({ datosUsuario, setPosts, posts }) => {
  const initPost = {
    autor: datosUsuario.usuario,
    titulo: '',
    mensaje: ''
  };

  const [form, setFormState] = useState(initPost);

  const handleInputChange = (e) => {
    // console.log(e.target.name);
    // console.log(e.target.value);
    setFormState({
      ...form,
      [e.target.name]: e.target.type === 'checkbox' ? e.target.checked : e.target.value
    });
  };

  const handleAdd = () => {
    setPosts([{ id: uuidv4(), autor: form.autor, titulo: form.titulo, mensaje: form.mensaje }, ...posts]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleAdd();
    setFormState(initPost);
  };

  return (
    <div className='row mt-4'>
      <div className='form-content w500 shadow'>
        <span className='form-title'>
          Autor: <b>{datosUsuario.usuario}</b>
        </span>
        <form onSubmit={handleSubmit}>
          <div className='col mb-3'>
            <label htmlFor='titulo' className='form-label'>
              Título
            </label>
            <input type='text' className='form-control' id='titulo' name='titulo' onChange={handleInputChange} value={form.titulo} />
          </div>
          <div className='col mb-3'>
            <label htmlFor='mensaje' className='form-label'>
              Mensaje
            </label>
            <textarea type='text' className='form-control' id='mensaje' name='mensaje' placeholder='Tu texto...' onChange={handleInputChange} value={form.mensaje} />
          </div>
          <div className='col-6'>
            {form.mensaje === '' || form.titulo === '' ? (
              <button className='btn btn-primary' type='submit' disabled>
                Nuevo post
              </button>
            ) : (
              <button className='btn btn-primary' type='submit'>
                Nuevo post
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

FormSendPost.propTypes = {
  datosUsuario: PropTypes.object,
  setPosts: PropTypes.func,
  posts: PropTypes.array
};

export default FormSendPost;
