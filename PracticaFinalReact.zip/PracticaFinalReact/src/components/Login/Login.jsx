import PropTypes from 'prop-types';
import { useState } from 'react';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Login = ({ setUsuario }) => {
  const showToast = () => {
    toast.error('Usuario o contraseña incorrectos', {
      autoClose: 2000,
      hideProgressBar: true,
      closeButton: false,
      position: 'top-left'
    });
  };

  const initUser = {
    usuario: '',
    password: ''
  };

  const [form, setFormState] = useState(initUser);

  const handleInputChange = (e) => {
    // console.log(e.target.name);
    // console.log(e.target.value);
    setFormState({
      ...form,
      [e.target.name]: e.target.type === 'checkbox' ? e.target.checked : e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (form.password === '123' && form.usuario !== '') {
      setUsuario(form);
    } else {
      showToast();
    }
  };
  return (
    <form className='d-flex' role='search' onSubmit={handleSubmit}>
      <input className='form-control me-2' type='text' placeholder='Usuario' aria-label='Search' name='usuario' onChange={handleInputChange} />
      <input className='form-control me-2' type='password' placeholder='Password' aria-label='Search' name='password' id='password' onChange={handleInputChange} />
      <button className='btn btn-warning' type='submit'>
        Login
      </button>
      <ToastContainer />
    </form>
  );
};

Login.propTypes = {
  setUsuario: PropTypes.func
};

export default Login;
