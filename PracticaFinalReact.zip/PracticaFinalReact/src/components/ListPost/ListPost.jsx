import PropTypes from 'prop-types';
import Post from '../Post';

const ListPost = ({ posts, handleDelete }) => {
  return (
    <div className='row mt-4'>
      {posts.map((post) => {
        return <Post key={post.id} id={post.id} autor={post.autor} titulo={post.titulo} mensaje={post.mensaje} handleDelete={handleDelete} />;
      })}
    </div>
  );
};
ListPost.propTypes = {
  posts: PropTypes.array,
  handleDelete: PropTypes.func
};
export default ListPost;
