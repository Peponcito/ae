import PropTypes from 'prop-types';

const Post = ({ id, autor, titulo, mensaje, handleDelete }) => {
  return (
    <div className='post-content w500 shadow mb-4'>
      <div className='col padding-10 '>
        <p className='form-label underline'>
          <b>{titulo}</b>
        </p>
      </div>

      <div className='col padding-10'>
        <span className='form-label'>{mensaje}</span>
      </div>

      <div className='col padding-10'>
        <p className='form-label'>
          <i>
            Written by <b>{autor}</b>
          </i>
          <button className='btn separar' type='button' onClick={() => handleDelete(id)}>
            <i className='bi bi-trash'></i>
          </button>
        </p>

        <div className='col'></div>
      </div>
    </div>
  );
};

Post.propTypes = {
  id: PropTypes.string,
  autor: PropTypes.string,
  titulo: PropTypes.string,
  mensaje: PropTypes.string,
  handleDelete: PropTypes.func
};

export default Post;
