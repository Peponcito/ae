import PropTypes from 'prop-types';
import FormSendPost from '../FormSendPost';
import ListPost from '../ListPost';

const ContainerPost = ({ datosUsuario, posts, setPosts, handleDelete }) => {
  return (
    <div className='row w100'>
      <div className='col mb-3'>{datosUsuario.password === '123' ? <FormSendPost datosUsuario={datosUsuario} setPosts={setPosts} posts={posts} /> : null}</div>
      <div className='col mb-3 overflow'>{posts.length > 0 && datosUsuario.password !== '' ? <ListPost posts={posts} handleDelete={handleDelete} /> : null}</div>
    </div>
  );
};

ContainerPost.propTypes = {
  datosUsuario: PropTypes.object,
  posts: PropTypes.array,
  setPosts: PropTypes.func,
  handleDelete: PropTypes.func
};

export default ContainerPost;
